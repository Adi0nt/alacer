package net.adiont.alacer.config;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Properties;

import org.junit.jupiter.api.Test;

class AlacerMixinPluginTest {

	@Test
	void boxExperimentIsSeparateAndStartupGated() {
		Properties file = new Properties();
		AlacerMixinPlugin plugin = new AlacerMixinPlugin();
		assertFalse(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin.EntityParticleBoxMixin"));
		assertFalse(AlacerMixinPlugin.particleBoxesEnabled(file));
		file.setProperty("render.reuseParticleBoxes.verify", "true");
		assertTrue(AlacerMixinPlugin.particleBoxesEnabled(file));
		try {
			System.setProperty("alacer.benchmark", "true");
			assertFalse(AlacerMixinPlugin.particleBoxesEnabled(file));
			System.setProperty("alacer.benchmark.toggle", " render.reuseParticleBoxes ");
			assertTrue(AlacerMixinPlugin.particleBoxesEnabled(file));
			assertFalse(AlacerMixinPlugin.particleMovementEnabled(file));
		} finally {
			System.clearProperty("alacer.benchmark");
			System.clearProperty("alacer.benchmark.toggle");
		}
	}

	@Test
	void movementExperimentHooksAreAbsentUnlessRequested() {
		Properties file = new Properties();
		AlacerMixinPlugin plugin = new AlacerMixinPlugin();
		assertFalse(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin.EntityParticleMovementMixin"));
		assertFalse(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin.ParticleCollisionMixin"));
		assertFalse(AlacerMixinPlugin.particleMovementEnabled(file));
		file.setProperty("render.fastParticleMovement.verify", "true");
		assertTrue(AlacerMixinPlugin.particleMovementEnabled(file));
		try {
			System.setProperty("alacer.benchmark", "true");
			assertFalse(AlacerMixinPlugin.particleMovementEnabled(file));
			System.setProperty("alacer.benchmark.toggle", " render.fastParticleMovement ");
			assertTrue(AlacerMixinPlugin.particleMovementEnabled(file));
		} finally {
			System.clearProperty("alacer.benchmark");
			System.clearProperty("alacer.benchmark.toggle");
		}
	}

	@Test
	void benchmarkStartupHooksIgnoreFileAndHonorExplicitOverrides() {
		Properties file = new Properties();
		file.setProperty("profiler.particleDetail", "true");
		file.setProperty("render.batchModelLists", "true");
		try {
			System.setProperty("alacer.benchmark", "true");
			assertFalse(AlacerMixinPlugin.particleDetailEnabled(file));
			assertFalse(AlacerMixinPlugin.modelBatchEnabled(file));
			file.setProperty("profiler.enabled", "false");
			System.setProperty("alacer.profiler.particleDetail", "true");
			assertTrue(AlacerMixinPlugin.particleDetailEnabled(file));
			System.setProperty("alacer.benchmark.toggle", "render.batchModelLists");
			assertTrue(AlacerMixinPlugin.modelBatchEnabled(file));
		} finally {
			System.clearProperty("alacer.benchmark");
			System.clearProperty("alacer.profiler.particleDetail");
			System.clearProperty("alacer.benchmark.toggle");
		}
	}

	@Test
	void everyChunkDiagnosticMixinIsGated() throws Exception {
		AlacerMixinPlugin plugin = new AlacerMixinPlugin();
		String[] hooks = {"ChunkBuildTimingMixin", "ChunkDispatcherTimingMixin", "ChunkTaskTimingMixin", "WorldRendererBackendTimingMixin"};
		for (String hook : hooks) { assertFalse(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin." + hook)); }
		java.lang.reflect.Field field = AlacerMixinPlugin.class.getDeclaredField("chunkDetail");
		field.setAccessible(true);
		field.setBoolean(plugin, true);
		for (String hook : hooks) { assertTrue(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin." + hook)); }
		assertTrue(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin.WorldRendererMixin"));
	}

	@Test
	void chunkTimingHooksAreAbsentUnlessRequestedAndProfilingEnabled() {
		Properties file = new Properties();
		assertFalse(AlacerMixinPlugin.chunkDetailEnabled(file));
		file.setProperty("profiler.chunkDetail", "true");
		assertTrue(AlacerMixinPlugin.chunkDetailEnabled(file));
		file.setProperty("profiler.enabled", "false");
		assertFalse(AlacerMixinPlugin.chunkDetailEnabled(file));
		try {
			System.setProperty("alacer.profiler.enabled", "true");
			assertTrue(AlacerMixinPlugin.chunkDetailEnabled(file));
			System.setProperty("alacer.profiler.chunkDetail", "false");
			assertFalse(AlacerMixinPlugin.chunkDetailEnabled(file));
		} finally {
			System.clearProperty("alacer.profiler.enabled");
			System.clearProperty("alacer.profiler.chunkDetail");
		}
	}

	@Test
	void modelExperimentHooksAreAbsentUnlessRequested() {
		Properties file = new Properties();
		assertFalse(AlacerMixinPlugin.modelBatchEnabled(file));
		file.setProperty("render.batchModelLists.verify", "true");
		assertTrue(AlacerMixinPlugin.modelBatchEnabled(file));
		file.clear();
		try {
			System.setProperty("alacer.benchmark.toggle", " render.batchModelLists ");
			assertTrue(AlacerMixinPlugin.modelBatchEnabled(file));
			System.setProperty("alacer.benchmark.toggle", "render.cacheClouds");
			assertFalse(AlacerMixinPlugin.modelBatchEnabled(file));
		} finally {
			System.clearProperty("alacer.benchmark.toggle");
		}
		file.setProperty("render.batchModelLists", "true");
		assertTrue(AlacerMixinPlugin.modelBatchEnabled(file));
	}

	@Test
	void shadowTimingHookIsAbsentUnlessRequested() {
		Properties file = new Properties();
		assertFalse(AlacerMixinPlugin.shadowTimingEnabled(file));
		file.setProperty("profiler.shadowTiming", "true");
		assertTrue(AlacerMixinPlugin.shadowTimingEnabled(file));
		file.setProperty("profiler.enabled", "false");
		assertFalse(AlacerMixinPlugin.shadowTimingEnabled(file));
	}

	@Test
	void particleDetailHooksAreAbsentUnlessRequested() throws Exception {
		Properties file = new Properties();
		assertFalse(AlacerMixinPlugin.particleDetailEnabled(file));
		file.setProperty("profiler.particleDetail", "true");
		assertTrue(AlacerMixinPlugin.particleDetailEnabled(file));
		file.setProperty("profiler.enabled", "false");
		assertFalse(AlacerMixinPlugin.particleDetailEnabled(file));
		AlacerMixinPlugin plugin = new AlacerMixinPlugin();
		String[] hooks = {"ParticleDetailMixin", "EntityParticleDetailMixin"};
		for (String hook : hooks) { assertFalse(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin." + hook)); }
		java.lang.reflect.Field field = AlacerMixinPlugin.class.getDeclaredField("particleDetail");
		field.setAccessible(true);
		field.setBoolean(plugin, true);
		for (String hook : hooks) { assertTrue(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin." + hook)); }
		assertTrue(plugin.shouldApplyMixin("unused", "net.adiont.alacer.mixin.ParticleManagerMixin"));
	}

	@Test
	void startupFlagsKeepTheConfiguredDefaultForInvalidValues() {
		Properties file = new Properties();
		assertTrue(AlacerMixinPlugin.flag(file, "test.stageFlag", true));
		assertFalse(AlacerMixinPlugin.flag(file, "test.stageFlag", false));
		file.setProperty("test.stageFlag", "invalid");
		assertTrue(AlacerMixinPlugin.flag(file, "test.stageFlag", true));
		assertFalse(AlacerMixinPlugin.flag(file, "test.stageFlag", false));
		file.setProperty("test.stageFlag", " FALSE ");
		assertFalse(AlacerMixinPlugin.flag(file, "test.stageFlag", true));
		file.setProperty("test.stageFlag", " TRUE ");
		assertTrue(AlacerMixinPlugin.flag(file, "test.stageFlag", false));
	}
}
